public class CajaDeAhorroDolares extends Cuenta{
}