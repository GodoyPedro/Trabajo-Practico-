import java.util.List;

public abstract class Cuenta extends Operaciones{

	protected double saldo;
	protected double saldoPrevio;
	protected String alias;
	protected List<String> movimientos;

	@Override
	public void depositar(double saldo){
		if(saldo < 0){
			throw new RuntimeException("El saldo a depositar debe ser positivo");
		}
		this.saldo += saldo;
		agregarMovimiento("depositarSaldo(" + saldo + ")");
	}
	
	@Override
	public void retirar(double cantidad) {
		if(cantidad > saldo){
			throw new RuntimeException("No posee el saldo necesario para realizar esta operacion");
		}
		saldo -= cantidad;
		agregarMovimiento("retirar(" + cantidad + ")");
	}

	@Override
	public double consultarSaldo() {
		agregarMovimiento("consultarSaldo()");
		return saldo;
	}

	public void agregarMovimiento(String movimiento){
		movimientos.add(movimiento);
	}

	public String consultarAlias(){
		agregarMovimiento("consultarAlias()");
		return alias;
	}

	public void guardarSaldoPrevio(){
		saldoPrevio = saldo;
	}
}