public interface CompraDeDolares {

	public void comprarDolares(CajaDeAhorroDolares cuenta, double cantidadDeDolares);
}