public interface Transferible extends Reversible{

	public void transferir(Cuenta cuenta, double cantidad);
}