public abstract class Operaciones {

	public void depositar(double cantidad) {
	}
	public void retirar(double cantidad) {
	}
	public double consultarSaldo() {
		return 0;
	}
}