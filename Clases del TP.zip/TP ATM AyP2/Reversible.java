public interface Reversible {
	
	public void revertirMovimiento();
}